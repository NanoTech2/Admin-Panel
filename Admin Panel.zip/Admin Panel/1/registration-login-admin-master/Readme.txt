How to run the User Registration & Login and User Management System With admin panel Project

1. Install xampp or wamp.
2. Install phpmyadmin.
3. Download the  zip file.

4. Extract the file and copy loginsystem folder

5.Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

6. Open PHPMyAdmin (http://localhost/phpmyadmin)

7. Create a database with name loginsystem

8. Import loginsystem.sql file(given inside the zip package in SQL file folder)

9.Run the script http://localhost/loginsystem (frontend)

10. For admin Panel http://localhost/loginsystem/admin

Credential for admin panel :

Username: admin
Password: Test @123

Credential for user panel : 

Username: demouser@gmail.com 
Password : Test@123